<?php
/*
 * Customer Assessment Type Choosing Page
 * 
 */
$GeneralThemeObject = new GeneralTheme();
?>

<!-- Choose Assesment Type -->

    <h3 class="fs-subtitle"><?php _e('Step 2: Lorem ipsum dolor sit amet, consectetur.',THEME_TEXTDOMAIN); ?></h3>
    <!-- Shipping Details  -->  
    	<section class="second-question-set"></section>
    <!-- End of Shipping Details  -->    
    <input type="button" name="previous" class="survey_prev action-button-previous" value="Back"/>
    <input type="button" name="next" id="thirdSurveyNext" class="survey_submit action-button" value="Submit Inventory"/>
    
        
    


<!-- End of Choose Assesment Type -->

    <?php
