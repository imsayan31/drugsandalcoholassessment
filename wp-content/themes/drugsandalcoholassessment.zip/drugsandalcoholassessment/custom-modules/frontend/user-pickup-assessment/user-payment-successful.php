<?php
/*
 * customer Registration Page
 * 
 */
$GeneralThemeObject = new GeneralTheme();
?>

<!-- Payment Successful -->

    <h3 class="fs-subtitle"><span>Step 5: </span><?php _e('Enter payment information',THEME_TEXTDOMAIN); ?></h3>
                <div class="text-center">
                    <span></span>
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/email_verify.png" /><br/>
                    <?php _e('Assessment Purchased', THEME_TEXTDOMAIN); ?>
                </div>

<!-- Payment Successful -->

    <?php
