<?php
/*
 * Customer Registration Page
 * 
 */
?>

<!-- Account Created -->
<h3 class="fs-subtitle"><span>Step 3:</span> Account Details</h3>

<span></span>
<div class="text-center">
<img src="<?php echo get_template_directory_uri(); ?>/assets/images/email_verify.png" /><br/>
<?php _e('Account Created', THEME_TEXTDOMAIN); ?></div>

<!-- End of Account Created -->

    <?php
